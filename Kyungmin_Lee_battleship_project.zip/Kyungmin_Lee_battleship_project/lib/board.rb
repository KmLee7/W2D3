class Board

    def initialize(n)
        @grid = Array.new(n) {Array.new(n, :N)}
        @size = n*n
    end
    def size
        @size
    end
    def [](pos)
        row,col = pos
        @grid[row][col]
    end
    def []=(pos,val)
        count = 0
        row,col = pos
        @grid[row][col] = val
    end
    def num_ships
        count = 0
        @grid.flatten.each do |el|

            if el == (:S)
                count += 1
            end
        end
        count
    end
    def attack(pos)
        if self[pos] == :S
            self[pos] = :H
            puts "you sunk my battleship!"
            return true
        else
            self[pos] = :X
            return false
        end
    end
    def place_random_ships
        ships = @size * 0.25
        while self.num_ships < ships
        random_row = rand(0...@grid.length)
        random_col = rand(0...@grid.length)
        random_pos = [random_row, random_col]
        self[random_pos] = :S
        end
    end
    def hidden_ships_grid
        @grid.map do |el1|
            el1.map do |el2|
                if el2 == :S
                    el2 = :N
                else
                    el2
                end
            end
        end
    end
  

    def self.print_grid(grid)
        grid.each do |el|
           puts el.join(" ")
        end
    end

    def cheat
        Board.print_grid(@grid)
    end
    def print
        hidden = self.hidden_ships_grid
        Board.print_grid(hidden)
    end
end
